import { Route } from "react-router-dom";
import { About } from "../pages/About";
import { Dashboard } from "../pages/Dashboard";
import { Home } from "../pages/Home";
import { Services } from "../pages/Services";
import { Login } from "../pages/Login";
import { ContactPage } from "../pages/ContactPage";

function Routes() {
  return (
    <>
      <Route exact path="/">
        <Home />
      </Route>
      <Route exact path="/login">
        <Login />
      </Route>
      <Route exact path="/dashboard">
        <Dashboard />
      </Route>
      <Route exact path="/about-us">
        <About />
      </Route>
      <Route exact path="/services">
        <Services />
      </Route>
      <Route exact path="/contact">
        <ContactPage />
      </Route>
    </>
  );
}

export default Routes;
