import { Link } from "react-router-dom";

function Navbar() {
  return (
    <div style={{ display: "flex", gap: 5, justifyContent: "center" }}>
      <div>
        <Link to="/">Home</Link>
      </div>
      <div>
        <Link to="/login">Login</Link>
      </div>
      <div>
        <Link to="/dashboard">Dashboard</Link>
      </div>
      <div>
        <Link to="/contact">Contact</Link>
      </div>
      <div>
        <Link to="/about-us">About</Link>
      </div>
      <div>
        <Link to="/services">Services</Link>
      </div>
    </div>
  );
}

export default Navbar;
