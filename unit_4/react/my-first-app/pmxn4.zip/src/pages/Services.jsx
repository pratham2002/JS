function Services() {
  return <div>Services</div>;
}
export { Services };
