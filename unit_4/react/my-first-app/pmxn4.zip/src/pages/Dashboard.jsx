import { useContext } from "react";
import { Redirect } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

function Dashboard() {
  const [auth, { handleSignOut }] = useContext(AuthContext);

  if (!auth) {
    return <Redirect exact to="/login" />;
  }

  return (
    <div>
      Dashboard
      <div>
        <button onClick={handleSignOut}>SignOut</button>
      </div>
    </div>
  );
}
export { Dashboard };
